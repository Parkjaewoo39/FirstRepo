﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Live_In_Adventure
{
    public class Story 
    {
        Screen screen = new Screen();

        public void mainStoryOne()
        {            
            screen.SetBattleScreen();

            Console.SetCursorPosition(30, 46);
            Console.WriteLine("어이! 이제 그만 내 자리에서 나오지?");
            Console.SetCursorPosition(30, 47);
            Console.WriteLine("(당신은 깨질듯한 머리를 잡으며 일어났다.)");
            Console.SetCursorPosition(30, 48);
            Console.WriteLine("(그리고 주위를 둘러보니 험상굳은 ");
            Console.SetCursorPosition(30, 49);
            Console.WriteLine("사람이 노려보고있었다.)");
            Console.SetCursorPosition(30, 50);
            Console.WriteLine("형씨, 자리값은 받아야겠어");



            
        }
        public void mainStoryTwe()
        {
            Console.SetCursorPosition(30, 46);
            Console.WriteLine("어이! 이제 그만 내 자리에서 나오지?");
            Console.SetCursorPosition(30, 47);
            Console.WriteLine("(당신은 깨질듯한 머리를 잡으며 일어났다.)");
            Console.SetCursorPosition(30, 48);
            Console.WriteLine("(그리고 주위를 둘러보니 험상굳은 ");
            Console.SetCursorPosition(30, 49);
            Console.WriteLine("사람이 노려보고있었다.)");
            Console.SetCursorPosition(30, 50);
            Console.WriteLine("형씨, 자리값은 받아야겠어");

        }
        public void sumStory()
        {
           
        }

    }
}
