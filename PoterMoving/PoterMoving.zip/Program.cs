﻿using System;

namespace PoterMoving
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Board1 board1 = new Board1();

        }
    }
}